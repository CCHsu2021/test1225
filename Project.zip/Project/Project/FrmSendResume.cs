﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class FrmSendResume : Form
    {
        public FrmSendResume()
        {
            InitializeComponent();
        }

        private void FrmSendResume_Load(object sender, EventArgs e)
        {
            dbhelloEntities1 db = new dbhelloEntities1();

            var jobVacancyTB = from p in db.tJobVacancy
                               select p;
            tJobVacancy job = jobVacancyTB.FirstOrDefault(p => p.fJobID == FrmSerchJob.PK);

            var companyInfoTB = from p in db.tCompanyBasic
                                select p;
            tCompanyBasic company = companyInfoTB.FirstOrDefault(p => p.fBAN == job.fCompanyID);

            var memberFC = from p in db.tMember
                           where p.fAccount.Equals(txtMemberInfo.Text)
                           select p;

            var resumeFC = from p in db.StudentResume
                           where p.fAccount.Equals(txtMemberInfo.Text)
                           select p;

            var coverLetterTempFC = from p in db.tMemberCoverLetterTemp
                                    where p.fAccount.Equals(txtMemberInfo.Text)
                                    select p;

            var studentInfoFC = from p in db.StudentBasic
                                select p;
            StudentBasic studentInfo = studentInfoFC.FirstOrDefault(p => p.fAccount == txtMemberInfo.Text);

            labShowJobName.Text = job.fJobName;
            labShowCompanyName.Text = company.fName;

            foreach (StudentResume t in resumeFC)
            {
                cmbChoseResume.Items.Add(t);
                cmbChoseResume.ValueMember = t.ResumeID.ToString();
                cmbChoseResume.DisplayMember = t.ResumeID.ToString();
            }

            labSHowMemberPhone.Text = studentInfo.Phone;
            labShowMemberEmail.Text = studentInfo.Email;

            cmbContactTime.Items.Add("上午9點到12點");
            cmbContactTime.Items.Add("下午1點到6點");

            if (coverLetterTempFC != null)
            {
                foreach (tMemberCoverLetterTemp t in coverLetterTempFC)
                {
                    cmbChoseCoverLetter.Items.Add(t);
                    cmbChoseCoverLetter.ValueMember = t.CoverLetterID.ToString();
                    cmbChoseCoverLetter.DisplayMember = t.CoverLetterName;
                }

            }

        }

         

        private void cmbChoseCoverLetter_SelectedIndexChanged(object sender, EventArgs e)
        {
            dbhelloEntities1 db = new dbhelloEntities1();

            var coverLetterTempFC = from p in db.tMemberCoverLetterTemp
                                    //where p.CoverLetterID.Equals(cmbChoseCoverLetter.SelectedValue)
                                    select p;
            tMemberCoverLetterTemp coverLetterTemp = coverLetterTempFC.FirstOrDefault(p => 
            p.CoverLetterID.Equals(cmbChoseCoverLetter.SelectedValue));

            txtCoverLetterName.Text = coverLetterTemp.CoverLetterName;
            txtCoverLetter.Text = coverLetterTemp.CoverLetterContent;
            btnSavetoCoverLetter.Visible = true;
        }

        private void btnSavetoCoverLetter_Click(object sender, EventArgs e)
        {
            
            tMemberCoverLetterTemp memberCoverLetterTemp = new tMemberCoverLetterTemp();

            memberCoverLetterTemp.CoverLetterName = txtCoverLetterName.Text;
            memberCoverLetterTemp.CoverLetterContent = txtCoverLetter.Text;


            dbhelloEntities1 db = new dbhelloEntities1();

            var coverLetterTempFC = from p in db.tMemberCoverLetterTemp
                                    select p;
            tMemberCoverLetterTemp coverLetterTemp = coverLetterTempFC.FirstOrDefault(p =>
            p.CoverLetterID.Equals(cmbChoseCoverLetter.SelectedValue));

            coverLetterTemp.CoverLetterName = memberCoverLetterTemp.CoverLetterName;
            coverLetterTemp.CoverLetterContent = memberCoverLetterTemp.CoverLetterContent;

            db.SaveChanges();
            

        }

        private void btnSaveNewTemp_Click(object sender, EventArgs e)
        {
            if (txtCoverLetterName.Text == null || txtCoverLetterName.Text == "求職信名稱" || txtCoverLetter.Text == null)
            {
                MessageBox.Show($"求職信名稱或內容不得為空白！", "通知訊息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            tMemberCoverLetterTemp memberCoverLetterTemp = new tMemberCoverLetterTemp();
            memberCoverLetterTemp.CoverLetterName = txtCoverLetterName.Text;
            memberCoverLetterTemp.CoverLetterContent = txtCoverLetter.Text;
            memberCoverLetterTemp.fAccount = txtMemberInfo.Text;

            dbhelloEntities1 db = new dbhelloEntities1();
            db.tMemberCoverLetterTemp.Add(memberCoverLetterTemp);
            db.SaveChanges();

        }


        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private static tMemberResumeSend AllResumeSendInfo;

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            AllResumeSendInfo.ResumeID = (long)(cmbChoseResume.SelectedValue);
            AllResumeSendInfo.fAccount = txtMemberInfo.Text;                     //todo 會員資料來源更改
            AllResumeSendInfo.fJobID = FrmSerchJob.PK;
            AllResumeSendInfo.ContactPhone = labMemberPhone.Text;
            AllResumeSendInfo.ContactEmail = labMemberEmail.Text;
            AllResumeSendInfo.ComReadOrNot = "未讀";
            AllResumeSendInfo.TimeToContact = cmbContactTime.Text;
            AllResumeSendInfo.CoverLetter = txtCoverLetter.Text;
            AllResumeSendInfo.CreatTime = DateTime.Now.ToString("yyyyMMddhhmm");
            AllResumeSendInfo.ModifyTime = DateTime.Now.ToString("yyyyMMddhhmm");        

            dbhelloEntities1 db = new dbhelloEntities1();
            db.tMemberResumeSend.Add(AllResumeSendInfo);
            db.SaveChanges();
        }

        private void txtCoverLetterName_MouseDown(object sender, MouseEventArgs e)
        {
            txtCoverLetterName.Text = "";
        }

        private void txtCoverLetterName_Leave(object sender, EventArgs e)
        {
            if (txtCoverLetterName.Text == "")
                txtCoverLetterName.Text = "求職信名稱";
        }
        public tMemberResumeSend GetAllResumeSendInfo()
        {
            return AllResumeSendInfo;
        }
    }
}
