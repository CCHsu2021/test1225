﻿
namespace Project
{
    partial class FrmInvitation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMemberInfo = new System.Windows.Forms.TextBox();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.labShowAccountName = new System.Windows.Forms.Label();
            this.labAccountName = new System.Windows.Forms.Label();
            this.btnSaveToRespondTemp = new System.Windows.Forms.Button();
            this.btnSaveNewTemp = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.labEmail = new System.Windows.Forms.Label();
            this.labCompanyWindow = new System.Windows.Forms.Label();
            this.labWindowPhone = new System.Windows.Forms.Label();
            this.labWindowEmail = new System.Windows.Forms.Label();
            this.labJobName = new System.Windows.Forms.Label();
            this.labShowPhone = new System.Windows.Forms.Label();
            this.labShowEmail = new System.Windows.Forms.Label();
            this.labShowJobName = new System.Windows.Forms.Label();
            this.labInterviewContent = new System.Windows.Forms.Label();
            this.txtInterviewContentName = new System.Windows.Forms.TextBox();
            this.cmbChoseRespondTemp = new System.Windows.Forms.ComboBox();
            this.txtRespond = new System.Windows.Forms.TextBox();
            this.labInterviewTime = new System.Windows.Forms.Label();
            this.txtInterviewTime = new System.Windows.Forms.TextBox();
            this.txtInterviewAddress = new System.Windows.Forms.TextBox();
            this.labInterviewAddress = new System.Windows.Forms.Label();
            this.txtMemberRespondTime = new System.Windows.Forms.TextBox();
            this.labMemberRespondTime = new System.Windows.Forms.Label();
            this.txtShowCompanyWindow = new System.Windows.Forms.TextBox();
            this.txtShowWindowPhone = new System.Windows.Forms.TextBox();
            this.txtShowWindowEmail = new System.Windows.Forms.TextBox();
            this.labShowContactTime = new System.Windows.Forms.Label();
            this.labContactTime = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtMemberInfo
            // 
            this.txtMemberInfo.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtMemberInfo.Location = new System.Drawing.Point(597, 36);
            this.txtMemberInfo.Name = "txtMemberInfo";
            this.txtMemberInfo.Size = new System.Drawing.Size(163, 34);
            this.txtMemberInfo.TabIndex = 72;
            this.txtMemberInfo.Text = "示範用";
            // 
            // btnConfirm
            // 
            this.btnConfirm.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnConfirm.Location = new System.Drawing.Point(597, 907);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(163, 42);
            this.btnConfirm.TabIndex = 71;
            this.btnConfirm.Text = "邀約";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnCancel.Location = new System.Drawing.Point(428, 907);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(163, 42);
            this.btnCancel.TabIndex = 70;
            this.btnCancel.Text = "取消";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // labShowAccountName
            // 
            this.labShowAccountName.AutoSize = true;
            this.labShowAccountName.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowAccountName.Location = new System.Drawing.Point(207, 45);
            this.labShowAccountName.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labShowAccountName.Name = "labShowAccountName";
            this.labShowAccountName.Size = new System.Drawing.Size(228, 25);
            this.labShowAccountName.TabIndex = 66;
            this.labShowAccountName.Text = "labShowAccountName";
            // 
            // labAccountName
            // 
            this.labAccountName.AutoSize = true;
            this.labAccountName.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labAccountName.Location = new System.Drawing.Point(85, 45);
            this.labAccountName.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labAccountName.Name = "labAccountName";
            this.labAccountName.Size = new System.Drawing.Size(112, 25);
            this.labAccountName.TabIndex = 53;
            this.labAccountName.Text = "應徵者姓名";
            // 
            // btnSaveToRespondTemp
            // 
            this.btnSaveToRespondTemp.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnSaveToRespondTemp.Location = new System.Drawing.Point(354, 691);
            this.btnSaveToRespondTemp.Name = "btnSaveToRespondTemp";
            this.btnSaveToRespondTemp.Size = new System.Drawing.Size(163, 42);
            this.btnSaveToRespondTemp.TabIndex = 65;
            this.btnSaveToRespondTemp.Text = "儲存";
            this.btnSaveToRespondTemp.UseVisualStyleBackColor = true;
            this.btnSaveToRespondTemp.Click += new System.EventHandler(this.btnSaveToRespondTemp_Click);
            // 
            // btnSaveNewTemp
            // 
            this.btnSaveNewTemp.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnSaveNewTemp.Location = new System.Drawing.Point(185, 691);
            this.btnSaveNewTemp.Name = "btnSaveNewTemp";
            this.btnSaveNewTemp.Size = new System.Drawing.Size(163, 42);
            this.btnSaveNewTemp.TabIndex = 73;
            this.btnSaveNewTemp.Text = "另存範本";
            this.btnSaveNewTemp.UseVisualStyleBackColor = true;
            this.btnSaveNewTemp.Click += new System.EventHandler(this.btnSaveNewTemp_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(85, 90);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 25);
            this.label1.TabIndex = 74;
            this.label1.Text = "聯絡電話";
            // 
            // labEmail
            // 
            this.labEmail.AutoSize = true;
            this.labEmail.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labEmail.Location = new System.Drawing.Point(85, 135);
            this.labEmail.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labEmail.Name = "labEmail";
            this.labEmail.Size = new System.Drawing.Size(92, 25);
            this.labEmail.TabIndex = 75;
            this.labEmail.Text = "聯絡信箱";
            // 
            // labCompanyWindow
            // 
            this.labCompanyWindow.AutoSize = true;
            this.labCompanyWindow.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labCompanyWindow.Location = new System.Drawing.Point(85, 225);
            this.labCompanyWindow.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labCompanyWindow.Name = "labCompanyWindow";
            this.labCompanyWindow.Size = new System.Drawing.Size(92, 25);
            this.labCompanyWindow.TabIndex = 76;
            this.labCompanyWindow.Text = "公司窗口";
            // 
            // labWindowPhone
            // 
            this.labWindowPhone.AutoSize = true;
            this.labWindowPhone.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labWindowPhone.Location = new System.Drawing.Point(85, 270);
            this.labWindowPhone.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labWindowPhone.Name = "labWindowPhone";
            this.labWindowPhone.Size = new System.Drawing.Size(132, 25);
            this.labWindowPhone.TabIndex = 77;
            this.labWindowPhone.Text = "窗口聯絡電話";
            // 
            // labWindowEmail
            // 
            this.labWindowEmail.AutoSize = true;
            this.labWindowEmail.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labWindowEmail.Location = new System.Drawing.Point(85, 315);
            this.labWindowEmail.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labWindowEmail.Name = "labWindowEmail";
            this.labWindowEmail.Size = new System.Drawing.Size(132, 25);
            this.labWindowEmail.TabIndex = 78;
            this.labWindowEmail.Text = "窗口聯絡信箱";
            // 
            // labJobName
            // 
            this.labJobName.AutoSize = true;
            this.labJobName.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labJobName.Location = new System.Drawing.Point(85, 360);
            this.labJobName.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labJobName.Name = "labJobName";
            this.labJobName.Size = new System.Drawing.Size(92, 25);
            this.labJobName.TabIndex = 79;
            this.labJobName.Text = "通知職務";
            // 
            // labShowPhone
            // 
            this.labShowPhone.AutoSize = true;
            this.labShowPhone.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowPhone.Location = new System.Drawing.Point(187, 90);
            this.labShowPhone.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labShowPhone.Name = "labShowPhone";
            this.labShowPhone.Size = new System.Drawing.Size(153, 25);
            this.labShowPhone.TabIndex = 80;
            this.labShowPhone.Text = "labShowPhone";
            // 
            // labShowEmail
            // 
            this.labShowEmail.AutoSize = true;
            this.labShowEmail.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowEmail.Location = new System.Drawing.Point(187, 135);
            this.labShowEmail.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labShowEmail.Name = "labShowEmail";
            this.labShowEmail.Size = new System.Drawing.Size(144, 25);
            this.labShowEmail.TabIndex = 81;
            this.labShowEmail.Text = "labShowEmail";
            // 
            // labShowJobName
            // 
            this.labShowJobName.AutoSize = true;
            this.labShowJobName.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowJobName.Location = new System.Drawing.Point(187, 360);
            this.labShowJobName.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labShowJobName.Name = "labShowJobName";
            this.labShowJobName.Size = new System.Drawing.Size(184, 25);
            this.labShowJobName.TabIndex = 85;
            this.labShowJobName.Text = "labShowJobName";
            // 
            // labInterviewContent
            // 
            this.labInterviewContent.AutoSize = true;
            this.labInterviewContent.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labInterviewContent.Location = new System.Drawing.Point(85, 405);
            this.labInterviewContent.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labInterviewContent.Name = "labInterviewContent";
            this.labInterviewContent.Size = new System.Drawing.Size(92, 25);
            this.labInterviewContent.TabIndex = 86;
            this.labInterviewContent.Text = "通知內容";
            // 
            // txtInterviewContentName
            // 
            this.txtInterviewContentName.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtInterviewContentName.Location = new System.Drawing.Point(185, 402);
            this.txtInterviewContentName.Name = "txtInterviewContentName";
            this.txtInterviewContentName.Size = new System.Drawing.Size(163, 34);
            this.txtInterviewContentName.TabIndex = 89;
            this.txtInterviewContentName.Text = "通知名稱";
            this.txtInterviewContentName.Leave += new System.EventHandler(this.txtInterviewContentName_Leave);
            this.txtInterviewContentName.MouseDown += new System.Windows.Forms.MouseEventHandler(this.txtInterviewContentName_MouseDown);
            // 
            // cmbChoseRespondTemp
            // 
            this.cmbChoseRespondTemp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbChoseRespondTemp.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cmbChoseRespondTemp.FormattingEnabled = true;
            this.cmbChoseRespondTemp.Location = new System.Drawing.Point(354, 402);
            this.cmbChoseRespondTemp.Name = "cmbChoseRespondTemp";
            this.cmbChoseRespondTemp.Size = new System.Drawing.Size(163, 33);
            this.cmbChoseRespondTemp.TabIndex = 88;
            this.cmbChoseRespondTemp.SelectedValueChanged += new System.EventHandler(this.cmbChoseRespondTemp_SelectedValueChanged);
            // 
            // txtRespond
            // 
            this.txtRespond.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtRespond.Location = new System.Drawing.Point(185, 443);
            this.txtRespond.MaxLength = 500;
            this.txtRespond.Multiline = true;
            this.txtRespond.Name = "txtRespond";
            this.txtRespond.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRespond.Size = new System.Drawing.Size(575, 242);
            this.txtRespond.TabIndex = 87;
            // 
            // labInterviewTime
            // 
            this.labInterviewTime.AutoSize = true;
            this.labInterviewTime.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labInterviewTime.Location = new System.Drawing.Point(85, 742);
            this.labInterviewTime.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labInterviewTime.Name = "labInterviewTime";
            this.labInterviewTime.Size = new System.Drawing.Size(92, 25);
            this.labInterviewTime.TabIndex = 90;
            this.labInterviewTime.Text = "面試時間";
            // 
            // txtInterviewTime
            // 
            this.txtInterviewTime.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtInterviewTime.Location = new System.Drawing.Point(185, 739);
            this.txtInterviewTime.Name = "txtInterviewTime";
            this.txtInterviewTime.Size = new System.Drawing.Size(163, 34);
            this.txtInterviewTime.TabIndex = 91;
            // 
            // txtInterviewAddress
            // 
            this.txtInterviewAddress.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtInterviewAddress.Location = new System.Drawing.Point(185, 784);
            this.txtInterviewAddress.Name = "txtInterviewAddress";
            this.txtInterviewAddress.Size = new System.Drawing.Size(163, 34);
            this.txtInterviewAddress.TabIndex = 93;
            // 
            // labInterviewAddress
            // 
            this.labInterviewAddress.AutoSize = true;
            this.labInterviewAddress.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labInterviewAddress.Location = new System.Drawing.Point(85, 787);
            this.labInterviewAddress.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labInterviewAddress.Name = "labInterviewAddress";
            this.labInterviewAddress.Size = new System.Drawing.Size(92, 25);
            this.labInterviewAddress.TabIndex = 92;
            this.labInterviewAddress.Text = "面試地點";
            // 
            // txtMemberRespondTime
            // 
            this.txtMemberRespondTime.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtMemberRespondTime.Location = new System.Drawing.Point(185, 829);
            this.txtMemberRespondTime.Name = "txtMemberRespondTime";
            this.txtMemberRespondTime.Size = new System.Drawing.Size(163, 34);
            this.txtMemberRespondTime.TabIndex = 95;
            // 
            // labMemberRespondTime
            // 
            this.labMemberRespondTime.AutoSize = true;
            this.labMemberRespondTime.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labMemberRespondTime.Location = new System.Drawing.Point(85, 832);
            this.labMemberRespondTime.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labMemberRespondTime.Name = "labMemberRespondTime";
            this.labMemberRespondTime.Size = new System.Drawing.Size(92, 25);
            this.labMemberRespondTime.TabIndex = 94;
            this.labMemberRespondTime.Text = "回覆時間";
            // 
            // txtShowCompanyWindow
            // 
            this.txtShowCompanyWindow.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtShowCompanyWindow.Location = new System.Drawing.Point(185, 222);
            this.txtShowCompanyWindow.Name = "txtShowCompanyWindow";
            this.txtShowCompanyWindow.Size = new System.Drawing.Size(163, 34);
            this.txtShowCompanyWindow.TabIndex = 96;
            // 
            // txtShowWindowPhone
            // 
            this.txtShowWindowPhone.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtShowWindowPhone.Location = new System.Drawing.Point(225, 267);
            this.txtShowWindowPhone.Name = "txtShowWindowPhone";
            this.txtShowWindowPhone.Size = new System.Drawing.Size(163, 34);
            this.txtShowWindowPhone.TabIndex = 97;
            // 
            // txtShowWindowEmail
            // 
            this.txtShowWindowEmail.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtShowWindowEmail.Location = new System.Drawing.Point(225, 312);
            this.txtShowWindowEmail.Name = "txtShowWindowEmail";
            this.txtShowWindowEmail.Size = new System.Drawing.Size(163, 34);
            this.txtShowWindowEmail.TabIndex = 98;
            // 
            // labShowContactTime
            // 
            this.labShowContactTime.AutoSize = true;
            this.labShowContactTime.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowContactTime.Location = new System.Drawing.Point(187, 180);
            this.labShowContactTime.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labShowContactTime.Name = "labShowContactTime";
            this.labShowContactTime.Size = new System.Drawing.Size(212, 25);
            this.labShowContactTime.TabIndex = 100;
            this.labShowContactTime.Text = "labShowContactTime";
            // 
            // labContactTime
            // 
            this.labContactTime.AutoSize = true;
            this.labContactTime.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labContactTime.Location = new System.Drawing.Point(85, 180);
            this.labContactTime.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labContactTime.Name = "labContactTime";
            this.labContactTime.Size = new System.Drawing.Size(92, 25);
            this.labContactTime.TabIndex = 99;
            this.labContactTime.Text = "聯絡信箱";
            // 
            // FrmInvitation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(841, 959);
            this.Controls.Add(this.labShowContactTime);
            this.Controls.Add(this.labContactTime);
            this.Controls.Add(this.txtShowWindowEmail);
            this.Controls.Add(this.txtShowWindowPhone);
            this.Controls.Add(this.txtShowCompanyWindow);
            this.Controls.Add(this.txtMemberRespondTime);
            this.Controls.Add(this.labMemberRespondTime);
            this.Controls.Add(this.txtInterviewAddress);
            this.Controls.Add(this.labInterviewAddress);
            this.Controls.Add(this.txtInterviewTime);
            this.Controls.Add(this.labInterviewTime);
            this.Controls.Add(this.txtInterviewContentName);
            this.Controls.Add(this.cmbChoseRespondTemp);
            this.Controls.Add(this.txtRespond);
            this.Controls.Add(this.labInterviewContent);
            this.Controls.Add(this.labShowJobName);
            this.Controls.Add(this.labShowEmail);
            this.Controls.Add(this.labShowPhone);
            this.Controls.Add(this.labJobName);
            this.Controls.Add(this.labWindowEmail);
            this.Controls.Add(this.labWindowPhone);
            this.Controls.Add(this.labCompanyWindow);
            this.Controls.Add(this.labEmail);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSaveNewTemp);
            this.Controls.Add(this.txtMemberInfo);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.labShowAccountName);
            this.Controls.Add(this.btnSaveToRespondTemp);
            this.Controls.Add(this.labAccountName);
            this.Name = "FrmInvitation";
            this.Text = "FrmInvitation";
            this.Load += new System.EventHandler(this.FrmInvitation_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMemberInfo;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label labShowAccountName;
        private System.Windows.Forms.Label labAccountName;
        private System.Windows.Forms.Button btnSaveToRespondTemp;
        private System.Windows.Forms.Button btnSaveNewTemp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labEmail;
        private System.Windows.Forms.Label labCompanyWindow;
        private System.Windows.Forms.Label labWindowPhone;
        private System.Windows.Forms.Label labWindowEmail;
        private System.Windows.Forms.Label labJobName;
        private System.Windows.Forms.Label labShowPhone;
        private System.Windows.Forms.Label labShowEmail;
        private System.Windows.Forms.Label labShowJobName;
        private System.Windows.Forms.Label labInterviewContent;
        private System.Windows.Forms.TextBox txtInterviewContentName;
        private System.Windows.Forms.ComboBox cmbChoseRespondTemp;
        private System.Windows.Forms.TextBox txtRespond;
        private System.Windows.Forms.Label labInterviewTime;
        private System.Windows.Forms.TextBox txtInterviewTime;
        private System.Windows.Forms.TextBox txtInterviewAddress;
        private System.Windows.Forms.Label labInterviewAddress;
        private System.Windows.Forms.TextBox txtMemberRespondTime;
        private System.Windows.Forms.Label labMemberRespondTime;
        private System.Windows.Forms.TextBox txtShowCompanyWindow;
        private System.Windows.Forms.TextBox txtShowWindowPhone;
        private System.Windows.Forms.TextBox txtShowWindowEmail;
        private System.Windows.Forms.Label labShowContactTime;
        private System.Windows.Forms.Label labContactTime;
    }
}