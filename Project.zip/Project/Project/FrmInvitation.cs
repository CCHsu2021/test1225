﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class FrmInvitation : Form
    {
        public FrmInvitation()
        {
            InitializeComponent();
        }

        private void FrmInvitation_Load(object sender, EventArgs e)
        {
            tMemberResumeSend AllResumeSendInfo = new FrmSendResume().GetAllResumeSendInfo();
            dbhelloEntities1 db = new dbhelloEntities1();

            StudentBasic studentInfo = db.StudentBasic.FirstOrDefault(p => p.fAccount == AllResumeSendInfo.fAccount);
            tJobVacancy jobVacancy = db.tJobVacancy.FirstOrDefault(p => p.fJobID == AllResumeSendInfo.fJobID);
            tCompanyBasic companyBasic = db.tCompanyBasic.FirstOrDefault(p => p.fBAN == jobVacancy.fCompanyID);

            var companyRespondTempFC = from p in db.tCompanyRespondTemp
                                       where p.CompanyID.Equals(jobVacancy.fCompanyID)
                                       select p;

            labShowAccountName.Text = studentInfo.Name;
            labShowPhone.Text = AllResumeSendInfo.ContactPhone;
            labShowEmail.Text = AllResumeSendInfo.ContactEmail;
            labShowContactTime.Text = AllResumeSendInfo.TimeToContact;
            txtShowCompanyWindow.Text = companyBasic.fName;
            txtShowWindowPhone.Text = $"{companyBasic.fPhoneCode + companyBasic.fPhone}";
            txtShowWindowEmail.Text = $"{companyBasic.fEmail}";
            labShowJobName.Text = jobVacancy.fJobName;

            if (companyRespondTempFC != null)
            {
                foreach (tCompanyRespondTemp t in companyRespondTempFC)
                {
                    cmbChoseRespondTemp.Items.Add(t);
                    cmbChoseRespondTemp.ValueMember = t.TempID.ToString();
                    cmbChoseRespondTemp.DisplayMember = t.TempName;
                }
            }



        }

        private void cmbChoseRespondTemp_SelectedValueChanged(object sender, EventArgs e)
        {
            dbhelloEntities1 db = new dbhelloEntities1();
            tCompanyRespondTemp companyRespondTemp = db.tCompanyRespondTemp.FirstOrDefault(p => p.TempID.Equals(cmbChoseRespondTemp.SelectedValue));

            txtInterviewContentName.Text = companyRespondTemp.TempName;
            txtRespond.Text = companyRespondTemp.TempContent;

            btnSaveToRespondTemp.Visible = true;

        }

        private void btnSaveToRespondTemp_Click(object sender, EventArgs e)
        {
            tCompanyRespondTemp companyRespondTemp = null;

            companyRespondTemp.TempName = txtInterviewContentName.Text;
            companyRespondTemp.TempContent = txtRespond.Text;

            dbhelloEntities1 db = null;
            tCompanyRespondTemp TempFromDB = db.tCompanyRespondTemp.FirstOrDefault(p =>
            p.TempID.Equals(cmbChoseRespondTemp.SelectedValue));

            TempFromDB.TempName = companyRespondTemp.TempName;
            TempFromDB.TempContent = companyRespondTemp.TempContent;

            db.SaveChanges();
        }

        private void btnSaveNewTemp_Click(object sender, EventArgs e)
        {
            if (txtInterviewContentName.Text == null || txtInterviewContentName.Text == "通知名稱" || txtRespond.Text == null)
            {
                MessageBox.Show($"通知名稱或內容不得為空白！", "通知訊息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            tCompanyRespondTemp companyRespondTemp = null;
            dbhelloEntities1 db = null;
            tMemberResumeSend AllResumeSendInfo = new FrmSendResume().GetAllResumeSendInfo();
            tJobVacancy jobVacancy = db.tJobVacancy.FirstOrDefault(p => p.fJobID == AllResumeSendInfo.fJobID);
            companyRespondTemp.CompanyID = jobVacancy.fCompanyID;
            companyRespondTemp.TempName = txtInterviewContentName.Text;
            companyRespondTemp.TempContent = txtRespond.Text;

            db.tCompanyRespondTemp.Add(companyRespondTemp);
            db.SaveChanges();

        }

        private static tCompanyRespond AllCompanyRespondInfo;

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            dbhelloEntities1 db = null;
            AllCompanyRespondInfo.CompanyWindow = txtShowCompanyWindow.Text;
            AllCompanyRespondInfo.CompanyWindowPhone = txtShowWindowPhone.Text;
            AllCompanyRespondInfo.CompanyWindowEMail = txtShowWindowEmail.Text;
            AllCompanyRespondInfo.InterviewState = "邀約面試";
            AllCompanyRespondInfo.InterviewTime = txtInterviewTime.Text;
            AllCompanyRespondInfo.InterviewAddress = txtInterviewAddress.Text;
            AllCompanyRespondInfo.MemberRespondTime = txtMemberRespondTime.Text;
            AllCompanyRespondInfo.InterviewContent = txtRespond.Text;
            AllCompanyRespondInfo.CreatTime = DateTime.Now.ToString("yyyyMMddhhmm");
            AllCompanyRespondInfo.ModifyTime = DateTime.Now.ToString("yyyyMMddhhmm");

            db.tCompanyRespond.Add(AllCompanyRespondInfo);
            db.SaveChanges();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public tCompanyRespond GetAllCompanyRespondInfo()
        {
            return AllCompanyRespondInfo;
        }

        private void txtInterviewContentName_MouseDown(object sender, MouseEventArgs e)
        {
            txtInterviewContentName.Text = "";
        }

        private void txtInterviewContentName_Leave(object sender, EventArgs e)
        {
            if (txtInterviewContentName.Text == "")
                txtInterviewContentName.Text = "通知名稱";
        }
    }
}
