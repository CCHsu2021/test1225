﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class FrmCompanyReadResume : Form
    {
        public FrmCompanyReadResume()
        {
            InitializeComponent();
        }

        dbhelloEntities1 db = new dbhelloEntities1();
        tMemberResumeSend AllResumeSendInfo = new FrmSendResume().GetAllResumeSendInfo();                                 //todo 不確定是否能這樣呼叫靜態方法。
        
        private void FrmCompanyReadResume_Load(object sender, EventArgs e)
        {
            

            var studentInfoFC = from p in db.StudentBasic
                                select p;
            StudentBasic studentInfo = studentInfoFC.FirstOrDefault(p => p.fAccount == AllResumeSendInfo.fAccount);

            var studentResumeFC = from p in db.StudentResume
                                  select p;
            StudentResume studentResume = studentResumeFC.FirstOrDefault(p => p.fAccount == AllResumeSendInfo.fAccount);


            labShowfAccount.Text = $"{studentInfo.Name}的履歷";
            labShowBasicInfo.Text = studentResume.rBasic;
            labShowWorkExp.Text = studentResume.rWorkExp;
            labShowLanguage.Text = studentResume.rLanguage;
            labShowEducation.Text = studentResume.rEducation;
            labShowSkill.Text = studentResume.rSkill;
            labShowPorfolio.Text = studentResume.rPortfolio;
            
        }

        private void btnAccept_Click(object sender, EventArgs e)
        {
            AllResumeSendInfo.ComReadOrNot = "已讀";
            tMemberResumeSend memberResumeSend = db.tMemberResumeSend.FirstOrDefault(p => p.ResumeSendID == AllResumeSendInfo.ResumeSendID);

            memberResumeSend.ComReadOrNot = AllResumeSendInfo.ComReadOrNot;
            
            db.SaveChanges();

            FrmInvitation frmInvitation = new FrmInvitation();
            frmInvitation.Show();
        }

    }
}
