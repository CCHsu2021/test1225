﻿
namespace Project
{
    partial class FrmJobInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labJobName = new System.Windows.Forms.Label();
            this.labComponyName = new System.Windows.Forms.Label();
            this.labOtherJob = new System.Windows.Forms.Label();
            this.labJobClass = new System.Windows.Forms.Label();
            this.labSalary = new System.Windows.Forms.Label();
            this.labEmployeesType = new System.Windows.Forms.Label();
            this.labWorkAddress = new System.Windows.Forms.Label();
            this.labWorkHour = new System.Windows.Forms.Label();
            this.labLeaveSystem = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labShowJobProfessionalSkill = new System.Windows.Forms.Label();
            this.labShowLanguage = new System.Windows.Forms.Label();
            this.labShowEducation = new System.Windows.Forms.Label();
            this.labShowWorkExperience = new System.Windows.Forms.Label();
            this.labJobProfessionalSkill = new System.Windows.Forms.Label();
            this.labLanguage = new System.Windows.Forms.Label();
            this.labEducation = new System.Windows.Forms.Label();
            this.labWorkExperience = new System.Windows.Forms.Label();
            this.labRequirement = new System.Windows.Forms.Label();
            this.labCompanyPhoto = new System.Windows.Forms.Label();
            this.pbCompanyPhoto1 = new System.Windows.Forms.PictureBox();
            this.pbCompanyPhoto2 = new System.Windows.Forms.PictureBox();
            this.pbCompanyPhoto3 = new System.Windows.Forms.PictureBox();
            this.pbCompanyPhoto4 = new System.Windows.Forms.PictureBox();
            this.pbCompanyPhoto5 = new System.Windows.Forms.PictureBox();
            this.pbCompanyPhoto6 = new System.Windows.Forms.PictureBox();
            this.pbCompanyPhoto7 = new System.Windows.Forms.PictureBox();
            this.pbCompanyPhoto8 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.labBenefits = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtShowBenefits = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.labShowLeaveSystem = new System.Windows.Forms.Label();
            this.labShowWorkHour = new System.Windows.Forms.Label();
            this.labShowWorkAddress = new System.Windows.Forms.Label();
            this.labShowEmployeesType = new System.Windows.Forms.Label();
            this.labShowSalary = new System.Windows.Forms.Label();
            this.labShowJobClass = new System.Windows.Forms.Label();
            this.txtShowfOther = new System.Windows.Forms.TextBox();
            this.labJobList = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.labShowContactEmail = new System.Windows.Forms.Label();
            this.labShowContactPhone = new System.Windows.Forms.Label();
            this.labShowContactHR = new System.Windows.Forms.Label();
            this.labContactEmail = new System.Windows.Forms.Label();
            this.labContactPhone = new System.Windows.Forms.Label();
            this.labContactHR = new System.Windows.Forms.Label();
            this.labContact = new System.Windows.Forms.Label();
            this.btnApply = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCompanyPhoto1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCompanyPhoto2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCompanyPhoto3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCompanyPhoto4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCompanyPhoto5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCompanyPhoto6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCompanyPhoto7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCompanyPhoto8)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // labJobName
            // 
            this.labJobName.Font = new System.Drawing.Font("微軟正黑體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labJobName.Location = new System.Drawing.Point(12, 9);
            this.labJobName.Margin = new System.Windows.Forms.Padding(3, 5, 3, 10);
            this.labJobName.Name = "labJobName";
            this.labJobName.Size = new System.Drawing.Size(396, 36);
            this.labJobName.TabIndex = 2;
            this.labJobName.Text = "職務名稱";
            // 
            // labComponyName
            // 
            this.labComponyName.AutoSize = true;
            this.labComponyName.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labComponyName.Location = new System.Drawing.Point(15, 60);
            this.labComponyName.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labComponyName.Name = "labComponyName";
            this.labComponyName.Size = new System.Drawing.Size(92, 25);
            this.labComponyName.TabIndex = 3;
            this.labComponyName.Text = "公司名稱";
            // 
            // labOtherJob
            // 
            this.labOtherJob.AutoSize = true;
            this.labOtherJob.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labOtherJob.Location = new System.Drawing.Point(166, 60);
            this.labOtherJob.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labOtherJob.Name = "labOtherJob";
            this.labOtherJob.Size = new System.Drawing.Size(152, 25);
            this.labOtherJob.TabIndex = 4;
            this.labOtherJob.Text = "本公司其他工作";
            this.labOtherJob.Click += new System.EventHandler(this.labOtherJob_Click);
            // 
            // labJobClass
            // 
            this.labJobClass.AutoSize = true;
            this.labJobClass.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labJobClass.Location = new System.Drawing.Point(3, 427);
            this.labJobClass.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labJobClass.Name = "labJobClass";
            this.labJobClass.Size = new System.Drawing.Size(92, 25);
            this.labJobClass.TabIndex = 6;
            this.labJobClass.Text = "職務類別";
            // 
            // labSalary
            // 
            this.labSalary.AutoSize = true;
            this.labSalary.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labSalary.Location = new System.Drawing.Point(3, 462);
            this.labSalary.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labSalary.Name = "labSalary";
            this.labSalary.Size = new System.Drawing.Size(92, 25);
            this.labSalary.TabIndex = 7;
            this.labSalary.Text = "工作待遇";
            // 
            // labEmployeesType
            // 
            this.labEmployeesType.AutoSize = true;
            this.labEmployeesType.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labEmployeesType.Location = new System.Drawing.Point(3, 497);
            this.labEmployeesType.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labEmployeesType.Name = "labEmployeesType";
            this.labEmployeesType.Size = new System.Drawing.Size(92, 25);
            this.labEmployeesType.TabIndex = 8;
            this.labEmployeesType.Text = "工作性質";
            // 
            // labWorkAddress
            // 
            this.labWorkAddress.AutoSize = true;
            this.labWorkAddress.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labWorkAddress.Location = new System.Drawing.Point(3, 532);
            this.labWorkAddress.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labWorkAddress.Name = "labWorkAddress";
            this.labWorkAddress.Size = new System.Drawing.Size(92, 25);
            this.labWorkAddress.TabIndex = 9;
            this.labWorkAddress.Text = "上班地點";
            // 
            // labWorkHour
            // 
            this.labWorkHour.AutoSize = true;
            this.labWorkHour.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labWorkHour.Location = new System.Drawing.Point(3, 567);
            this.labWorkHour.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labWorkHour.Name = "labWorkHour";
            this.labWorkHour.Size = new System.Drawing.Size(92, 25);
            this.labWorkHour.TabIndex = 10;
            this.labWorkHour.Text = "上班時段";
            // 
            // labLeaveSystem
            // 
            this.labLeaveSystem.AutoSize = true;
            this.labLeaveSystem.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labLeaveSystem.Location = new System.Drawing.Point(3, 602);
            this.labLeaveSystem.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labLeaveSystem.Name = "labLeaveSystem";
            this.labLeaveSystem.Size = new System.Drawing.Size(92, 25);
            this.labLeaveSystem.TabIndex = 11;
            this.labLeaveSystem.Text = "休假制度";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.labShowJobProfessionalSkill);
            this.panel1.Controls.Add(this.labShowLanguage);
            this.panel1.Controls.Add(this.labShowEducation);
            this.panel1.Controls.Add(this.labShowWorkExperience);
            this.panel1.Controls.Add(this.labJobProfessionalSkill);
            this.panel1.Controls.Add(this.labLanguage);
            this.panel1.Controls.Add(this.labEducation);
            this.panel1.Controls.Add(this.labWorkExperience);
            this.panel1.Controls.Add(this.labRequirement);
            this.panel1.Location = new System.Drawing.Point(12, 768);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(779, 275);
            this.panel1.TabIndex = 13;
            // 
            // labShowJobProfessionalSkill
            // 
            this.labShowJobProfessionalSkill.AutoSize = true;
            this.labShowJobProfessionalSkill.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowJobProfessionalSkill.Location = new System.Drawing.Point(101, 150);
            this.labShowJobProfessionalSkill.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labShowJobProfessionalSkill.Name = "labShowJobProfessionalSkill";
            this.labShowJobProfessionalSkill.Size = new System.Drawing.Size(278, 25);
            this.labShowJobProfessionalSkill.TabIndex = 44;
            this.labShowJobProfessionalSkill.Text = "labShowJobProfessionalSkill";
            // 
            // labShowLanguage
            // 
            this.labShowLanguage.AutoSize = true;
            this.labShowLanguage.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowLanguage.Location = new System.Drawing.Point(101, 115);
            this.labShowLanguage.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labShowLanguage.Name = "labShowLanguage";
            this.labShowLanguage.Size = new System.Drawing.Size(186, 25);
            this.labShowLanguage.TabIndex = 43;
            this.labShowLanguage.Text = "labShowLanguage";
            // 
            // labShowEducation
            // 
            this.labShowEducation.AutoSize = true;
            this.labShowEducation.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowEducation.Location = new System.Drawing.Point(101, 80);
            this.labShowEducation.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labShowEducation.Name = "labShowEducation";
            this.labShowEducation.Size = new System.Drawing.Size(187, 25);
            this.labShowEducation.TabIndex = 41;
            this.labShowEducation.Text = "labShowEducation";
            // 
            // labShowWorkExperience
            // 
            this.labShowWorkExperience.AutoSize = true;
            this.labShowWorkExperience.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowWorkExperience.Location = new System.Drawing.Point(101, 45);
            this.labShowWorkExperience.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labShowWorkExperience.Name = "labShowWorkExperience";
            this.labShowWorkExperience.Size = new System.Drawing.Size(245, 25);
            this.labShowWorkExperience.TabIndex = 40;
            this.labShowWorkExperience.Text = "labShowWorkExperience";
            // 
            // labJobProfessionalSkill
            // 
            this.labJobProfessionalSkill.AutoSize = true;
            this.labJobProfessionalSkill.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labJobProfessionalSkill.Location = new System.Drawing.Point(3, 150);
            this.labJobProfessionalSkill.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labJobProfessionalSkill.Name = "labJobProfessionalSkill";
            this.labJobProfessionalSkill.Size = new System.Drawing.Size(92, 25);
            this.labJobProfessionalSkill.TabIndex = 18;
            this.labJobProfessionalSkill.Text = "專業技能";
            // 
            // labLanguage
            // 
            this.labLanguage.AutoSize = true;
            this.labLanguage.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labLanguage.Location = new System.Drawing.Point(3, 115);
            this.labLanguage.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labLanguage.Name = "labLanguage";
            this.labLanguage.Size = new System.Drawing.Size(92, 25);
            this.labLanguage.TabIndex = 17;
            this.labLanguage.Text = "語言要求";
            // 
            // labEducation
            // 
            this.labEducation.AutoSize = true;
            this.labEducation.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labEducation.Location = new System.Drawing.Point(3, 80);
            this.labEducation.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labEducation.Name = "labEducation";
            this.labEducation.Size = new System.Drawing.Size(92, 25);
            this.labEducation.TabIndex = 15;
            this.labEducation.Text = "學歷要求";
            // 
            // labWorkExperience
            // 
            this.labWorkExperience.AutoSize = true;
            this.labWorkExperience.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labWorkExperience.Location = new System.Drawing.Point(3, 45);
            this.labWorkExperience.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labWorkExperience.Name = "labWorkExperience";
            this.labWorkExperience.Size = new System.Drawing.Size(92, 25);
            this.labWorkExperience.TabIndex = 14;
            this.labWorkExperience.Text = "工作經歷";
            // 
            // labRequirement
            // 
            this.labRequirement.AutoSize = true;
            this.labRequirement.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labRequirement.Location = new System.Drawing.Point(3, 5);
            this.labRequirement.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labRequirement.Name = "labRequirement";
            this.labRequirement.Size = new System.Drawing.Size(109, 30);
            this.labRequirement.TabIndex = 14;
            this.labRequirement.Text = "條件要求";
            // 
            // labCompanyPhoto
            // 
            this.labCompanyPhoto.AutoSize = true;
            this.labCompanyPhoto.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labCompanyPhoto.Location = new System.Drawing.Point(5, 9);
            this.labCompanyPhoto.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labCompanyPhoto.Name = "labCompanyPhoto";
            this.labCompanyPhoto.Size = new System.Drawing.Size(157, 30);
            this.labCompanyPhoto.TabIndex = 19;
            this.labCompanyPhoto.Text = "公司環境照片";
            // 
            // pbCompanyPhoto1
            // 
            this.pbCompanyPhoto1.Location = new System.Drawing.Point(10, 51);
            this.pbCompanyPhoto1.Margin = new System.Windows.Forms.Padding(10);
            this.pbCompanyPhoto1.Name = "pbCompanyPhoto1";
            this.pbCompanyPhoto1.Size = new System.Drawing.Size(225, 150);
            this.pbCompanyPhoto1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCompanyPhoto1.TabIndex = 20;
            this.pbCompanyPhoto1.TabStop = false;
            // 
            // pbCompanyPhoto2
            // 
            this.pbCompanyPhoto2.Location = new System.Drawing.Point(256, 51);
            this.pbCompanyPhoto2.Margin = new System.Windows.Forms.Padding(10);
            this.pbCompanyPhoto2.Name = "pbCompanyPhoto2";
            this.pbCompanyPhoto2.Size = new System.Drawing.Size(225, 150);
            this.pbCompanyPhoto2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCompanyPhoto2.TabIndex = 21;
            this.pbCompanyPhoto2.TabStop = false;
            // 
            // pbCompanyPhoto3
            // 
            this.pbCompanyPhoto3.Location = new System.Drawing.Point(501, 51);
            this.pbCompanyPhoto3.Margin = new System.Windows.Forms.Padding(10);
            this.pbCompanyPhoto3.Name = "pbCompanyPhoto3";
            this.pbCompanyPhoto3.Size = new System.Drawing.Size(225, 150);
            this.pbCompanyPhoto3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCompanyPhoto3.TabIndex = 22;
            this.pbCompanyPhoto3.TabStop = false;
            // 
            // pbCompanyPhoto4
            // 
            this.pbCompanyPhoto4.Location = new System.Drawing.Point(746, 51);
            this.pbCompanyPhoto4.Margin = new System.Windows.Forms.Padding(10);
            this.pbCompanyPhoto4.Name = "pbCompanyPhoto4";
            this.pbCompanyPhoto4.Size = new System.Drawing.Size(225, 150);
            this.pbCompanyPhoto4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCompanyPhoto4.TabIndex = 23;
            this.pbCompanyPhoto4.TabStop = false;
            // 
            // pbCompanyPhoto5
            // 
            this.pbCompanyPhoto5.Location = new System.Drawing.Point(10, 221);
            this.pbCompanyPhoto5.Margin = new System.Windows.Forms.Padding(10);
            this.pbCompanyPhoto5.Name = "pbCompanyPhoto5";
            this.pbCompanyPhoto5.Size = new System.Drawing.Size(225, 150);
            this.pbCompanyPhoto5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCompanyPhoto5.TabIndex = 24;
            this.pbCompanyPhoto5.TabStop = false;
            // 
            // pbCompanyPhoto6
            // 
            this.pbCompanyPhoto6.Location = new System.Drawing.Point(256, 221);
            this.pbCompanyPhoto6.Margin = new System.Windows.Forms.Padding(10);
            this.pbCompanyPhoto6.Name = "pbCompanyPhoto6";
            this.pbCompanyPhoto6.Size = new System.Drawing.Size(225, 150);
            this.pbCompanyPhoto6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCompanyPhoto6.TabIndex = 25;
            this.pbCompanyPhoto6.TabStop = false;
            // 
            // pbCompanyPhoto7
            // 
            this.pbCompanyPhoto7.Location = new System.Drawing.Point(501, 221);
            this.pbCompanyPhoto7.Margin = new System.Windows.Forms.Padding(10);
            this.pbCompanyPhoto7.Name = "pbCompanyPhoto7";
            this.pbCompanyPhoto7.Size = new System.Drawing.Size(225, 150);
            this.pbCompanyPhoto7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCompanyPhoto7.TabIndex = 26;
            this.pbCompanyPhoto7.TabStop = false;
            // 
            // pbCompanyPhoto8
            // 
            this.pbCompanyPhoto8.Location = new System.Drawing.Point(746, 221);
            this.pbCompanyPhoto8.Margin = new System.Windows.Forms.Padding(10);
            this.pbCompanyPhoto8.Name = "pbCompanyPhoto8";
            this.pbCompanyPhoto8.Size = new System.Drawing.Size(225, 150);
            this.pbCompanyPhoto8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCompanyPhoto8.TabIndex = 27;
            this.pbCompanyPhoto8.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.pbCompanyPhoto8);
            this.panel2.Controls.Add(this.pbCompanyPhoto7);
            this.panel2.Controls.Add(this.pbCompanyPhoto6);
            this.panel2.Controls.Add(this.pbCompanyPhoto5);
            this.panel2.Controls.Add(this.pbCompanyPhoto4);
            this.panel2.Controls.Add(this.pbCompanyPhoto3);
            this.panel2.Controls.Add(this.pbCompanyPhoto2);
            this.panel2.Controls.Add(this.pbCompanyPhoto1);
            this.panel2.Controls.Add(this.labCompanyPhoto);
            this.panel2.Location = new System.Drawing.Point(797, 91);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(981, 393);
            this.panel2.TabIndex = 28;
            // 
            // labBenefits
            // 
            this.labBenefits.AutoSize = true;
            this.labBenefits.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labBenefits.Location = new System.Drawing.Point(5, 7);
            this.labBenefits.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labBenefits.Name = "labBenefits";
            this.labBenefits.Size = new System.Drawing.Size(109, 30);
            this.labBenefits.TabIndex = 28;
            this.labBenefits.Text = "福利制度";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.txtShowBenefits);
            this.panel3.Controls.Add(this.labBenefits);
            this.panel3.Location = new System.Drawing.Point(797, 505);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(981, 208);
            this.panel3.TabIndex = 29;
            // 
            // txtShowBenefits
            // 
            this.txtShowBenefits.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtShowBenefits.Location = new System.Drawing.Point(10, 45);
            this.txtShowBenefits.Multiline = true;
            this.txtShowBenefits.Name = "txtShowBenefits";
            this.txtShowBenefits.ReadOnly = true;
            this.txtShowBenefits.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtShowBenefits.Size = new System.Drawing.Size(961, 160);
            this.txtShowBenefits.TabIndex = 31;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.labShowLeaveSystem);
            this.panel4.Controls.Add(this.labShowWorkHour);
            this.panel4.Controls.Add(this.labShowWorkAddress);
            this.panel4.Controls.Add(this.labShowEmployeesType);
            this.panel4.Controls.Add(this.labShowSalary);
            this.panel4.Controls.Add(this.labShowJobClass);
            this.panel4.Controls.Add(this.txtShowfOther);
            this.panel4.Controls.Add(this.labJobList);
            this.panel4.Controls.Add(this.labWorkAddress);
            this.panel4.Controls.Add(this.labEmployeesType);
            this.panel4.Controls.Add(this.labSalary);
            this.panel4.Controls.Add(this.labJobClass);
            this.panel4.Controls.Add(this.labLeaveSystem);
            this.panel4.Controls.Add(this.labWorkHour);
            this.panel4.Location = new System.Drawing.Point(12, 91);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(779, 667);
            this.panel4.TabIndex = 30;
            // 
            // labShowLeaveSystem
            // 
            this.labShowLeaveSystem.AutoSize = true;
            this.labShowLeaveSystem.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowLeaveSystem.Location = new System.Drawing.Point(101, 602);
            this.labShowLeaveSystem.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labShowLeaveSystem.Name = "labShowLeaveSystem";
            this.labShowLeaveSystem.Size = new System.Drawing.Size(213, 25);
            this.labShowLeaveSystem.TabIndex = 38;
            this.labShowLeaveSystem.Text = "labShowLeaveSystem";
            // 
            // labShowWorkHour
            // 
            this.labShowWorkHour.AutoSize = true;
            this.labShowWorkHour.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowWorkHour.Location = new System.Drawing.Point(101, 567);
            this.labShowWorkHour.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labShowWorkHour.Name = "labShowWorkHour";
            this.labShowWorkHour.Size = new System.Drawing.Size(191, 25);
            this.labShowWorkHour.TabIndex = 37;
            this.labShowWorkHour.Text = "labShowWorkHour";
            // 
            // labShowWorkAddress
            // 
            this.labShowWorkAddress.AutoSize = true;
            this.labShowWorkAddress.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowWorkAddress.Location = new System.Drawing.Point(101, 532);
            this.labShowWorkAddress.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labShowWorkAddress.Name = "labShowWorkAddress";
            this.labShowWorkAddress.Size = new System.Drawing.Size(220, 25);
            this.labShowWorkAddress.TabIndex = 36;
            this.labShowWorkAddress.Text = "labShowWorkAddress";
            // 
            // labShowEmployeesType
            // 
            this.labShowEmployeesType.AutoSize = true;
            this.labShowEmployeesType.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowEmployeesType.Location = new System.Drawing.Point(101, 497);
            this.labShowEmployeesType.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labShowEmployeesType.Name = "labShowEmployeesType";
            this.labShowEmployeesType.Size = new System.Drawing.Size(240, 25);
            this.labShowEmployeesType.TabIndex = 35;
            this.labShowEmployeesType.Text = "labShowEmployeesType";
            // 
            // labShowSalary
            // 
            this.labShowSalary.AutoSize = true;
            this.labShowSalary.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowSalary.Location = new System.Drawing.Point(101, 462);
            this.labShowSalary.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labShowSalary.Name = "labShowSalary";
            this.labShowSalary.Size = new System.Drawing.Size(148, 25);
            this.labShowSalary.TabIndex = 34;
            this.labShowSalary.Text = "labShowSalary";
            // 
            // labShowJobClass
            // 
            this.labShowJobClass.AutoSize = true;
            this.labShowJobClass.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowJobClass.Location = new System.Drawing.Point(101, 427);
            this.labShowJobClass.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labShowJobClass.Name = "labShowJobClass";
            this.labShowJobClass.Size = new System.Drawing.Size(174, 25);
            this.labShowJobClass.TabIndex = 33;
            this.labShowJobClass.Text = "labShowJobClass";
            // 
            // txtShowfOther
            // 
            this.txtShowfOther.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtShowfOther.Location = new System.Drawing.Point(8, 47);
            this.txtShowfOther.Multiline = true;
            this.txtShowfOther.Name = "txtShowfOther";
            this.txtShowfOther.ReadOnly = true;
            this.txtShowfOther.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtShowfOther.Size = new System.Drawing.Size(768, 372);
            this.txtShowfOther.TabIndex = 32;
            // 
            // labJobList
            // 
            this.labJobList.AutoSize = true;
            this.labJobList.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labJobList.Location = new System.Drawing.Point(3, 9);
            this.labJobList.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labJobList.Name = "labJobList";
            this.labJobList.Size = new System.Drawing.Size(109, 30);
            this.labJobList.TabIndex = 29;
            this.labJobList.Text = "工作內容";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.labShowContactEmail);
            this.panel5.Controls.Add(this.labShowContactPhone);
            this.panel5.Controls.Add(this.labShowContactHR);
            this.panel5.Controls.Add(this.labContactEmail);
            this.panel5.Controls.Add(this.labContactPhone);
            this.panel5.Controls.Add(this.labContactHR);
            this.panel5.Controls.Add(this.labContact);
            this.panel5.Location = new System.Drawing.Point(797, 723);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(981, 147);
            this.panel5.TabIndex = 31;
            // 
            // labShowContactEmail
            // 
            this.labShowContactEmail.AutoSize = true;
            this.labShowContactEmail.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowContactEmail.Location = new System.Drawing.Point(103, 115);
            this.labShowContactEmail.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labShowContactEmail.Name = "labShowContactEmail";
            this.labShowContactEmail.Size = new System.Drawing.Size(217, 25);
            this.labShowContactEmail.TabIndex = 35;
            this.labShowContactEmail.Text = "labShowContactEmail";
            // 
            // labShowContactPhone
            // 
            this.labShowContactPhone.AutoSize = true;
            this.labShowContactPhone.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowContactPhone.Location = new System.Drawing.Point(103, 80);
            this.labShowContactPhone.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labShowContactPhone.Name = "labShowContactPhone";
            this.labShowContactPhone.Size = new System.Drawing.Size(226, 25);
            this.labShowContactPhone.TabIndex = 34;
            this.labShowContactPhone.Text = "labShowContactPhone";
            // 
            // labShowContactHR
            // 
            this.labShowContactHR.AutoSize = true;
            this.labShowContactHR.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowContactHR.Location = new System.Drawing.Point(83, 45);
            this.labShowContactHR.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labShowContactHR.Name = "labShowContactHR";
            this.labShowContactHR.Size = new System.Drawing.Size(194, 25);
            this.labShowContactHR.TabIndex = 33;
            this.labShowContactHR.Text = "labShowContactHR";
            // 
            // labContactEmail
            // 
            this.labContactEmail.AutoSize = true;
            this.labContactEmail.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labContactEmail.Location = new System.Drawing.Point(5, 115);
            this.labContactEmail.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labContactEmail.Name = "labContactEmail";
            this.labContactEmail.Size = new System.Drawing.Size(92, 25);
            this.labContactEmail.TabIndex = 32;
            this.labContactEmail.Text = "聯絡信箱";
            // 
            // labContactPhone
            // 
            this.labContactPhone.AutoSize = true;
            this.labContactPhone.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labContactPhone.Location = new System.Drawing.Point(5, 80);
            this.labContactPhone.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labContactPhone.Name = "labContactPhone";
            this.labContactPhone.Size = new System.Drawing.Size(92, 25);
            this.labContactPhone.TabIndex = 31;
            this.labContactPhone.Text = "聯絡電話";
            // 
            // labContactHR
            // 
            this.labContactHR.AutoSize = true;
            this.labContactHR.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labContactHR.Location = new System.Drawing.Point(5, 45);
            this.labContactHR.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labContactHR.Name = "labContactHR";
            this.labContactHR.Size = new System.Drawing.Size(72, 25);
            this.labContactHR.TabIndex = 19;
            this.labContactHR.Text = "聯絡人";
            // 
            // labContact
            // 
            this.labContact.AutoSize = true;
            this.labContact.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labContact.Location = new System.Drawing.Point(5, 5);
            this.labContact.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.labContact.Name = "labContact";
            this.labContact.Size = new System.Drawing.Size(109, 30);
            this.labContact.TabIndex = 30;
            this.labContact.Text = "聯絡方式";
            // 
            // btnApply
            // 
            this.btnApply.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnApply.Location = new System.Drawing.Point(1295, 980);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new System.Drawing.Size(228, 46);
            this.btnApply.TabIndex = 32;
            this.btnApply.Text = "應徵";
            this.btnApply.UseVisualStyleBackColor = true;
            this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnCancel.Location = new System.Drawing.Point(1550, 980);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(228, 46);
            this.btnCancel.TabIndex = 33;
            this.btnCancel.Text = "取消";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // FrmJobInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1789, 1055);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnApply);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.labOtherJob);
            this.Controls.Add(this.labComponyName);
            this.Controls.Add(this.labJobName);
            this.Name = "FrmJobInfo";
            this.Text = "FrmJobInfo";
            this.Load += new System.EventHandler(this.FrmJobInfo_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCompanyPhoto1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCompanyPhoto2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCompanyPhoto3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCompanyPhoto4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCompanyPhoto5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCompanyPhoto6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCompanyPhoto7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCompanyPhoto8)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labJobName;
        private System.Windows.Forms.Label labComponyName;
        private System.Windows.Forms.Label labOtherJob;
        private System.Windows.Forms.Label labJobClass;
        private System.Windows.Forms.Label labSalary;
        private System.Windows.Forms.Label labEmployeesType;
        private System.Windows.Forms.Label labWorkAddress;
        private System.Windows.Forms.Label labWorkHour;
        private System.Windows.Forms.Label labLeaveSystem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labRequirement;
        private System.Windows.Forms.Label labJobProfessionalSkill;
        private System.Windows.Forms.Label labLanguage;
        private System.Windows.Forms.Label labEducation;
        private System.Windows.Forms.Label labWorkExperience;
        private System.Windows.Forms.Label labCompanyPhoto;
        private System.Windows.Forms.PictureBox pbCompanyPhoto1;
        private System.Windows.Forms.PictureBox pbCompanyPhoto2;
        private System.Windows.Forms.PictureBox pbCompanyPhoto3;
        private System.Windows.Forms.PictureBox pbCompanyPhoto4;
        private System.Windows.Forms.PictureBox pbCompanyPhoto5;
        private System.Windows.Forms.PictureBox pbCompanyPhoto6;
        private System.Windows.Forms.PictureBox pbCompanyPhoto7;
        private System.Windows.Forms.PictureBox pbCompanyPhoto8;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label labBenefits;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label labJobList;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox txtShowBenefits;
        private System.Windows.Forms.Label labContact;
        private System.Windows.Forms.Label labContactEmail;
        private System.Windows.Forms.Label labContactPhone;
        private System.Windows.Forms.Label labContactHR;
        private System.Windows.Forms.TextBox txtShowfOther;
        private System.Windows.Forms.Label labShowWorkAddress;
        private System.Windows.Forms.Label labShowEmployeesType;
        private System.Windows.Forms.Label labShowSalary;
        private System.Windows.Forms.Label labShowJobClass;
        private System.Windows.Forms.Label labShowLeaveSystem;
        private System.Windows.Forms.Label labShowWorkHour;
        private System.Windows.Forms.Label labShowJobProfessionalSkill;
        private System.Windows.Forms.Label labShowLanguage;
        private System.Windows.Forms.Label labShowEducation;
        private System.Windows.Forms.Label labShowWorkExperience;
        private System.Windows.Forms.Label labShowContactEmail;
        private System.Windows.Forms.Label labShowContactPhone;
        private System.Windows.Forms.Label labShowContactHR;
        private System.Windows.Forms.Button btnApply;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}