﻿
namespace Project
{
    partial class FrmSerchJob
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSerch = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbJobLocation = new System.Windows.Forms.ComboBox();
            this.cmbJobType = new System.Windows.Forms.ComboBox();
            this.cmbSkill = new System.Windows.Forms.ComboBox();
            this.labSalaryRange = new System.Windows.Forms.Label();
            this.txtSalaryMin = new System.Windows.Forms.TextBox();
            this.txtSalaryMax = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnResetSerch = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtSerch
            // 
            this.txtSerch.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtSerch.Location = new System.Drawing.Point(32, 61);
            this.txtSerch.Name = "txtSerch";
            this.txtSerch.Size = new System.Drawing.Size(535, 34);
            this.txtSerch.TabIndex = 0;
            this.txtSerch.Text = "關鍵字搜尋";
            this.txtSerch.Leave += new System.EventHandler(this.txtSerch_Leave);
            this.txtSerch.MouseDown += new System.Windows.Forms.MouseEventHandler(this.txtSerch_MouseDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(30, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 30);
            this.label1.TabIndex = 1;
            this.label1.Text = "職缺搜尋";
            // 
            // cmbJobLocation
            // 
            this.cmbJobLocation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbJobLocation.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cmbJobLocation.FormattingEnabled = true;
            this.cmbJobLocation.Location = new System.Drawing.Point(150, 106);
            this.cmbJobLocation.Margin = new System.Windows.Forms.Padding(5);
            this.cmbJobLocation.Name = "cmbJobLocation";
            this.cmbJobLocation.Size = new System.Drawing.Size(135, 33);
            this.cmbJobLocation.TabIndex = 2;
            // 
            // cmbJobType
            // 
            this.cmbJobType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbJobType.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cmbJobType.FormattingEnabled = true;
            this.cmbJobType.Location = new System.Drawing.Point(150, 149);
            this.cmbJobType.Margin = new System.Windows.Forms.Padding(5);
            this.cmbJobType.Name = "cmbJobType";
            this.cmbJobType.Size = new System.Drawing.Size(135, 33);
            this.cmbJobType.TabIndex = 3;
            // 
            // cmbSkill
            // 
            this.cmbSkill.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSkill.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cmbSkill.FormattingEnabled = true;
            this.cmbSkill.Location = new System.Drawing.Point(150, 192);
            this.cmbSkill.Margin = new System.Windows.Forms.Padding(5);
            this.cmbSkill.Name = "cmbSkill";
            this.cmbSkill.Size = new System.Drawing.Size(135, 33);
            this.cmbSkill.TabIndex = 4;
            // 
            // labSalaryRange
            // 
            this.labSalaryRange.AutoSize = true;
            this.labSalaryRange.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labSalaryRange.Location = new System.Drawing.Point(30, 243);
            this.labSalaryRange.Name = "labSalaryRange";
            this.labSalaryRange.Size = new System.Drawing.Size(112, 25);
            this.labSalaryRange.TabIndex = 5;
            this.labSalaryRange.Text = "薪資區間：";
            // 
            // txtSalaryMin
            // 
            this.txtSalaryMin.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtSalaryMin.Location = new System.Drawing.Point(148, 240);
            this.txtSalaryMin.Name = "txtSalaryMin";
            this.txtSalaryMin.Size = new System.Drawing.Size(84, 34);
            this.txtSalaryMin.TabIndex = 6;
            // 
            // txtSalaryMax
            // 
            this.txtSalaryMax.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtSalaryMax.Location = new System.Drawing.Point(271, 240);
            this.txtSalaryMax.Name = "txtSalaryMax";
            this.txtSalaryMax.Size = new System.Drawing.Size(84, 34);
            this.txtSalaryMax.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(238, 243);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 25);
            this.label2.TabIndex = 8;
            this.label2.Text = "~";
            // 
            // btnConfirm
            // 
            this.btnConfirm.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnConfirm.Location = new System.Drawing.Point(573, 61);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(151, 34);
            this.btnConfirm.TabIndex = 10;
            this.btnConfirm.Text = "確認";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(30, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 25);
            this.label3.TabIndex = 11;
            this.label3.Text = "地區搜尋：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(30, 152);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 25);
            this.label4.TabIndex = 12;
            this.label4.Text = "職務搜尋：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(30, 195);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(112, 25);
            this.label5.TabIndex = 13;
            this.label5.Text = "技術搜尋：";
            // 
            // btnResetSerch
            // 
            this.btnResetSerch.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnResetSerch.Location = new System.Drawing.Point(573, 240);
            this.btnResetSerch.Name = "btnResetSerch";
            this.btnResetSerch.Size = new System.Drawing.Size(151, 34);
            this.btnResetSerch.TabIndex = 14;
            this.btnResetSerch.Text = "重設";
            this.btnResetSerch.UseVisualStyleBackColor = true;
            this.btnResetSerch.Click += new System.EventHandler(this.btnResetSerch_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(32, 297);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 27;
            this.dataGridView1.Size = new System.Drawing.Size(1086, 492);
            this.dataGridView1.TabIndex = 15;
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            // 
            // FrmSerchJob
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1130, 801);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnResetSerch);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtSalaryMax);
            this.Controls.Add(this.txtSalaryMin);
            this.Controls.Add(this.labSalaryRange);
            this.Controls.Add(this.cmbSkill);
            this.Controls.Add(this.cmbJobType);
            this.Controls.Add(this.cmbJobLocation);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtSerch);
            this.Name = "FrmSerchJob";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.FrmSerchJob_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSerch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbJobLocation;
        private System.Windows.Forms.ComboBox cmbJobType;
        private System.Windows.Forms.ComboBox cmbSkill;
        private System.Windows.Forms.Label labSalaryRange;
        private System.Windows.Forms.TextBox txtSalaryMin;
        private System.Windows.Forms.TextBox txtSalaryMax;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnResetSerch;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}

