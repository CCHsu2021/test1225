﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class FrmSerchJob : Form
    {
        public FrmSerchJob()
        {
            InitializeComponent();
            ReFillItem();
        }

        private void ReFillItem()
        {
            dbhelloEntities1 db = new dbhelloEntities1();
            var locationTB = from p in db.tCityContrast
                             select p;
            foreach (tCityContrast t in locationTB)
            {
                cmbJobLocation.Items.Add(t);
                cmbJobLocation.DisplayMember = $"{t.fCityName + t.fDistrictName}";
            }

            var jobClassTB = from p in db.tJobList
                             select p;
            foreach (tJobList t in jobClassTB)
            {
                cmbJobType.Items.Add(t);
                cmbJobType.DisplayMember = t.fJobListName;
            }

            var skillType = from p in db.tSkill
                            select p;
            foreach (tSkill t in skillType)
            {
                cmbSkill.Items.Add(t);
                cmbSkill.DisplayMember = t.fSkillName;
            }
        }


        private void FrmSerchJob_Load(object sender, EventArgs e)
        {
            
            

        }

        
        private void btnConfirm_Click(object sender, EventArgs e)
        {
            dbhelloEntities1 db = new dbhelloEntities1();

            var jobVacancyTB = from p in db.tJobVacancy
                               select p;

            var JobAndCompany = from p in jobVacancyTB
                                join o in db.tCompanyBasic on p.fCompanyID equals o.fBAN
                                select new
                                {
                                    p,
                                    o
                                };
            var innerClassType = from p in JobAndCompany
                                 join o in db.tJobList on p.p.fJobID equals o.JobListID
                                 select new
                                 {
                                     p,
                                     o.fJobListName
                                 };
            var innerSkillTable = from p in innerClassType
                                  join o in db.tSkill on p.p.p.fJobID equals o.fJobID
                                  select new
                                  {
                                      p,
                                      o.fSkillName
                                  };
            var condition = from p in innerSkillTable
                            where p.p.p.p.fJobName.Contains(txtSerch.Text.Trim())
                            && (p.p.p.p.fCity + p.p.p.p.fDistrict).Equals(cmbJobLocation.Text)
                            && p.p.fJobListName.Equals(cmbJobType.Text)
                            && p.fSkillName.Equals(cmbSkill.Text)
                            select new
                            {
                                職務ID = p.p.p.p.fJobID,
                                職務姓名 = p.p.p.p.fJobName,
                                公司名稱 = p.p.p.o.fName,
                                工作地區 = p.p.p.p.fWorkAddress,
                                工作經歷 = p.p.p.p.fWorkEXP,
                                學歷要求 = p.p.p.p.fEducation,
                                工作內容 = p.p.p.p.fOther,
                            };

            dataGridView1.DataSource = condition.ToList();

            dataGridView1.Columns[0].Width = 30;
            dataGridView1.Columns[1].Width = 100;        //設定dataGridView1裡的每個欄位寬度。
            dataGridView1.Columns[2].Width = 100;
            dataGridView1.Columns[3].Width = 100;
            dataGridView1.Columns[4].Width = 50;
            dataGridView1.Columns[5].Width = 50;
            dataGridView1.Columns[6].Width = 500;
            

            //設定基數Row與偶數Row的顏色不同。
            bool isChanged = false;
            foreach (DataGridViewRow r in dataGridView1.Rows)
            {
                r.DefaultCellStyle.Font = new Font("微軟正黑體", 14);        //設定預設字體與大小。
                r.DefaultCellStyle.BackColor = Color.WhiteSmoke;
                if (isChanged)
                {
                    r.DefaultCellStyle.BackColor = Color.LightBlue;
                }
                isChanged = !isChanged;
            }
        }

        

        private void txtSerch_MouseDown(object sender, MouseEventArgs e)
        {
            txtSerch.Text = "";
        }

        private void txtSerch_Leave(object sender, EventArgs e)
        {
            if(txtSerch.Text == "")
            txtSerch.Text = "關鍵字搜尋";
        }

        private void btnResetSerch_Click(object sender, EventArgs e)
        {
            txtSerch.Text = "關鍵字搜尋";
            cmbJobLocation.Items.Clear();
            cmbJobType.Items.Clear();
            cmbSkill.Items.Clear();
            ReFillItem();
        }

        internal static long PK;

        public long GetJobID()
        {
            return PK;
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            PK = Convert.ToInt64(dataGridView1.Rows[e.RowIndex].Cells[0].Value);

            FrmJobInfo frmJobInfo = new FrmJobInfo();
            frmJobInfo.SetInfo(PK);
            frmJobInfo.Show();

        }
    }
}
