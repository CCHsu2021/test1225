﻿
namespace Project
{
    partial class FrmSendResume
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labJobName = new System.Windows.Forms.Label();
            this.labCompanyName = new System.Windows.Forms.Label();
            this.labChoseResume = new System.Windows.Forms.Label();
            this.labMemberPhone = new System.Windows.Forms.Label();
            this.labMemberEmail = new System.Windows.Forms.Label();
            this.labContactTime = new System.Windows.Forms.Label();
            this.labCoverLetter = new System.Windows.Forms.Label();
            this.cmbChoseResume = new System.Windows.Forms.ComboBox();
            this.cmbContactTime = new System.Windows.Forms.ComboBox();
            this.txtCoverLetter = new System.Windows.Forms.TextBox();
            this.btnSavetoCoverLetter = new System.Windows.Forms.Button();
            this.labShowJobName = new System.Windows.Forms.Label();
            this.labShowCompanyName = new System.Windows.Forms.Label();
            this.cmbChoseCoverLetter = new System.Windows.Forms.ComboBox();
            this.txtCoverLetterName = new System.Windows.Forms.TextBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.txtMemberInfo = new System.Windows.Forms.TextBox();
            this.btnSaveNewTemp = new System.Windows.Forms.Button();
            this.labSHowMemberPhone = new System.Windows.Forms.Label();
            this.labShowMemberEmail = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labJobName
            // 
            this.labJobName.AutoSize = true;
            this.labJobName.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labJobName.Location = new System.Drawing.Point(52, 52);
            this.labJobName.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labJobName.Name = "labJobName";
            this.labJobName.Size = new System.Drawing.Size(92, 25);
            this.labJobName.TabIndex = 32;
            this.labJobName.Text = "職務名稱";
            // 
            // labCompanyName
            // 
            this.labCompanyName.AutoSize = true;
            this.labCompanyName.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labCompanyName.Location = new System.Drawing.Point(52, 97);
            this.labCompanyName.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labCompanyName.Name = "labCompanyName";
            this.labCompanyName.Size = new System.Drawing.Size(92, 25);
            this.labCompanyName.TabIndex = 33;
            this.labCompanyName.Text = "公司名稱";
            // 
            // labChoseResume
            // 
            this.labChoseResume.AutoSize = true;
            this.labChoseResume.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labChoseResume.Location = new System.Drawing.Point(52, 142);
            this.labChoseResume.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labChoseResume.Name = "labChoseResume";
            this.labChoseResume.Size = new System.Drawing.Size(92, 25);
            this.labChoseResume.TabIndex = 34;
            this.labChoseResume.Text = "選擇履歷";
            // 
            // labMemberPhone
            // 
            this.labMemberPhone.AutoSize = true;
            this.labMemberPhone.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labMemberPhone.Location = new System.Drawing.Point(52, 187);
            this.labMemberPhone.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labMemberPhone.Name = "labMemberPhone";
            this.labMemberPhone.Size = new System.Drawing.Size(92, 25);
            this.labMemberPhone.TabIndex = 35;
            this.labMemberPhone.Text = "聯絡電話";
            // 
            // labMemberEmail
            // 
            this.labMemberEmail.AutoSize = true;
            this.labMemberEmail.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labMemberEmail.Location = new System.Drawing.Point(52, 232);
            this.labMemberEmail.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labMemberEmail.Name = "labMemberEmail";
            this.labMemberEmail.Size = new System.Drawing.Size(92, 25);
            this.labMemberEmail.TabIndex = 36;
            this.labMemberEmail.Text = "聯絡信箱";
            // 
            // labContactTime
            // 
            this.labContactTime.AutoSize = true;
            this.labContactTime.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labContactTime.Location = new System.Drawing.Point(52, 277);
            this.labContactTime.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labContactTime.Name = "labContactTime";
            this.labContactTime.Size = new System.Drawing.Size(92, 25);
            this.labContactTime.TabIndex = 37;
            this.labContactTime.Text = "聯絡時間";
            // 
            // labCoverLetter
            // 
            this.labCoverLetter.AutoSize = true;
            this.labCoverLetter.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labCoverLetter.Location = new System.Drawing.Point(72, 322);
            this.labCoverLetter.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labCoverLetter.Name = "labCoverLetter";
            this.labCoverLetter.Size = new System.Drawing.Size(72, 25);
            this.labCoverLetter.TabIndex = 38;
            this.labCoverLetter.Text = "求職信";
            // 
            // cmbChoseResume
            // 
            this.cmbChoseResume.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbChoseResume.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cmbChoseResume.FormattingEnabled = true;
            this.cmbChoseResume.Location = new System.Drawing.Point(152, 139);
            this.cmbChoseResume.Name = "cmbChoseResume";
            this.cmbChoseResume.Size = new System.Drawing.Size(163, 33);
            this.cmbChoseResume.TabIndex = 39;
            // 
            // cmbContactTime
            // 
            this.cmbContactTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbContactTime.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cmbContactTime.FormattingEnabled = true;
            this.cmbContactTime.Location = new System.Drawing.Point(152, 274);
            this.cmbContactTime.Name = "cmbContactTime";
            this.cmbContactTime.Size = new System.Drawing.Size(163, 33);
            this.cmbContactTime.TabIndex = 42;
            // 
            // txtCoverLetter
            // 
            this.txtCoverLetter.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtCoverLetter.Location = new System.Drawing.Point(152, 360);
            this.txtCoverLetter.MaxLength = 500;
            this.txtCoverLetter.Multiline = true;
            this.txtCoverLetter.Name = "txtCoverLetter";
            this.txtCoverLetter.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtCoverLetter.Size = new System.Drawing.Size(575, 242);
            this.txtCoverLetter.TabIndex = 43;
            // 
            // btnSavetoCoverLetter
            // 
            this.btnSavetoCoverLetter.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnSavetoCoverLetter.Location = new System.Drawing.Point(321, 608);
            this.btnSavetoCoverLetter.Name = "btnSavetoCoverLetter";
            this.btnSavetoCoverLetter.Size = new System.Drawing.Size(163, 42);
            this.btnSavetoCoverLetter.TabIndex = 44;
            this.btnSavetoCoverLetter.Text = "儲存";
            this.btnSavetoCoverLetter.UseVisualStyleBackColor = true;
            this.btnSavetoCoverLetter.Click += new System.EventHandler(this.btnSavetoCoverLetter_Click);
            // 
            // labShowJobName
            // 
            this.labShowJobName.AutoSize = true;
            this.labShowJobName.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowJobName.Location = new System.Drawing.Point(154, 52);
            this.labShowJobName.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labShowJobName.Name = "labShowJobName";
            this.labShowJobName.Size = new System.Drawing.Size(184, 25);
            this.labShowJobName.TabIndex = 45;
            this.labShowJobName.Text = "labShowJobName";
            // 
            // labShowCompanyName
            // 
            this.labShowCompanyName.AutoSize = true;
            this.labShowCompanyName.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowCompanyName.Location = new System.Drawing.Point(154, 97);
            this.labShowCompanyName.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labShowCompanyName.Name = "labShowCompanyName";
            this.labShowCompanyName.Size = new System.Drawing.Size(241, 25);
            this.labShowCompanyName.TabIndex = 46;
            this.labShowCompanyName.Text = "labShowCompanyName";
            // 
            // cmbChoseCoverLetter
            // 
            this.cmbChoseCoverLetter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbChoseCoverLetter.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cmbChoseCoverLetter.FormattingEnabled = true;
            this.cmbChoseCoverLetter.Location = new System.Drawing.Point(321, 319);
            this.cmbChoseCoverLetter.Name = "cmbChoseCoverLetter";
            this.cmbChoseCoverLetter.Size = new System.Drawing.Size(163, 33);
            this.cmbChoseCoverLetter.TabIndex = 47;
            this.cmbChoseCoverLetter.SelectedIndexChanged += new System.EventHandler(this.cmbChoseCoverLetter_SelectedIndexChanged);
            // 
            // txtCoverLetterName
            // 
            this.txtCoverLetterName.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtCoverLetterName.Location = new System.Drawing.Point(152, 319);
            this.txtCoverLetterName.Name = "txtCoverLetterName";
            this.txtCoverLetterName.Size = new System.Drawing.Size(163, 34);
            this.txtCoverLetterName.TabIndex = 48;
            this.txtCoverLetterName.Text = "求職信名稱";
            this.txtCoverLetterName.Leave += new System.EventHandler(this.txtCoverLetterName_Leave);
            this.txtCoverLetterName.MouseDown += new System.Windows.Forms.MouseEventHandler(this.txtCoverLetterName_MouseDown);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnCancel.Location = new System.Drawing.Point(395, 706);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(163, 42);
            this.btnCancel.TabIndex = 49;
            this.btnCancel.Text = "取消";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnConfirm
            // 
            this.btnConfirm.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnConfirm.Location = new System.Drawing.Point(564, 706);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(163, 42);
            this.btnConfirm.TabIndex = 50;
            this.btnConfirm.Text = "確認投遞";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // txtMemberInfo
            // 
            this.txtMemberInfo.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtMemberInfo.Location = new System.Drawing.Point(468, 49);
            this.txtMemberInfo.Name = "txtMemberInfo";
            this.txtMemberInfo.Size = new System.Drawing.Size(163, 34);
            this.txtMemberInfo.TabIndex = 51;
            this.txtMemberInfo.Text = "示範用";
            // 
            // btnSaveNewTemp
            // 
            this.btnSaveNewTemp.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnSaveNewTemp.Location = new System.Drawing.Point(152, 608);
            this.btnSaveNewTemp.Name = "btnSaveNewTemp";
            this.btnSaveNewTemp.Size = new System.Drawing.Size(163, 42);
            this.btnSaveNewTemp.TabIndex = 52;
            this.btnSaveNewTemp.Text = "另存範本";
            this.btnSaveNewTemp.UseVisualStyleBackColor = true;
            this.btnSaveNewTemp.Click += new System.EventHandler(this.btnSaveNewTemp_Click);
            // 
            // labSHowMemberPhone
            // 
            this.labSHowMemberPhone.AutoSize = true;
            this.labSHowMemberPhone.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labSHowMemberPhone.Location = new System.Drawing.Point(154, 187);
            this.labSHowMemberPhone.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labSHowMemberPhone.Name = "labSHowMemberPhone";
            this.labSHowMemberPhone.Size = new System.Drawing.Size(236, 25);
            this.labSHowMemberPhone.TabIndex = 53;
            this.labSHowMemberPhone.Text = "labSHowMemberPhone";
            // 
            // labShowMemberEmail
            // 
            this.labShowMemberEmail.AutoSize = true;
            this.labShowMemberEmail.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowMemberEmail.Location = new System.Drawing.Point(154, 232);
            this.labShowMemberEmail.Margin = new System.Windows.Forms.Padding(5, 10, 5, 10);
            this.labShowMemberEmail.Name = "labShowMemberEmail";
            this.labShowMemberEmail.Size = new System.Drawing.Size(224, 25);
            this.labShowMemberEmail.TabIndex = 54;
            this.labShowMemberEmail.Text = "labShowMemberEmail";
            // 
            // FrmSendResume
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 760);
            this.Controls.Add(this.labShowMemberEmail);
            this.Controls.Add(this.labSHowMemberPhone);
            this.Controls.Add(this.btnSaveNewTemp);
            this.Controls.Add(this.txtMemberInfo);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.txtCoverLetterName);
            this.Controls.Add(this.cmbChoseCoverLetter);
            this.Controls.Add(this.labShowCompanyName);
            this.Controls.Add(this.labShowJobName);
            this.Controls.Add(this.btnSavetoCoverLetter);
            this.Controls.Add(this.txtCoverLetter);
            this.Controls.Add(this.cmbContactTime);
            this.Controls.Add(this.cmbChoseResume);
            this.Controls.Add(this.labCoverLetter);
            this.Controls.Add(this.labContactTime);
            this.Controls.Add(this.labMemberEmail);
            this.Controls.Add(this.labMemberPhone);
            this.Controls.Add(this.labChoseResume);
            this.Controls.Add(this.labCompanyName);
            this.Controls.Add(this.labJobName);
            this.Name = "FrmSendResume";
            this.Text = "FrmSendResume";
            this.Load += new System.EventHandler(this.FrmSendResume_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labJobName;
        private System.Windows.Forms.Label labCompanyName;
        private System.Windows.Forms.Label labChoseResume;
        private System.Windows.Forms.Label labMemberPhone;
        private System.Windows.Forms.Label labMemberEmail;
        private System.Windows.Forms.Label labContactTime;
        private System.Windows.Forms.Label labCoverLetter;
        private System.Windows.Forms.ComboBox cmbChoseResume;
        private System.Windows.Forms.ComboBox cmbContactTime;
        private System.Windows.Forms.TextBox txtCoverLetter;
        private System.Windows.Forms.Button btnSavetoCoverLetter;
        private System.Windows.Forms.Label labShowJobName;
        private System.Windows.Forms.Label labShowCompanyName;
        private System.Windows.Forms.ComboBox cmbChoseCoverLetter;
        private System.Windows.Forms.TextBox txtCoverLetterName;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.TextBox txtMemberInfo;
        private System.Windows.Forms.Button btnSaveNewTemp;
        private System.Windows.Forms.Label labSHowMemberPhone;
        private System.Windows.Forms.Label labShowMemberEmail;
    }
}