﻿
namespace Project
{
    partial class FrmCompanyReadResume
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.labShowfAccount = new System.Windows.Forms.Label();
            this.labBasicInfo = new System.Windows.Forms.Label();
            this.labShowBasicInfo = new System.Windows.Forms.Label();
            this.labLanguage = new System.Windows.Forms.Label();
            this.labShowLanguage = new System.Windows.Forms.Label();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.labWorkExp = new System.Windows.Forms.Label();
            this.labShowWorkExp = new System.Windows.Forms.Label();
            this.labEducation = new System.Windows.Forms.Label();
            this.labShowEducation = new System.Windows.Forms.Label();
            this.labSkill = new System.Windows.Forms.Label();
            this.labShowSkill = new System.Windows.Forms.Label();
            this.labPorfolio = new System.Windows.Forms.Label();
            this.labShowPorfolio = new System.Windows.Forms.Label();
            this.btnDecline = new System.Windows.Forms.Button();
            this.btnAccept = new System.Windows.Forms.Button();
            this.btnDeclineWithNoMessage = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(12, 12);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.flowLayoutPanel1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.flowLayoutPanel2);
            this.splitContainer1.Size = new System.Drawing.Size(1177, 804);
            this.splitContainer1.SplitterDistance = 588;
            this.splitContainer1.TabIndex = 0;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoSize = true;
            this.flowLayoutPanel1.Controls.Add(this.labShowfAccount);
            this.flowLayoutPanel1.Controls.Add(this.labBasicInfo);
            this.flowLayoutPanel1.Controls.Add(this.labShowBasicInfo);
            this.flowLayoutPanel1.Controls.Add(this.labWorkExp);
            this.flowLayoutPanel1.Controls.Add(this.labShowWorkExp);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(588, 804);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // labShowfAccount
            // 
            this.labShowfAccount.AutoSize = true;
            this.labShowfAccount.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowfAccount.Location = new System.Drawing.Point(3, 0);
            this.labShowfAccount.Name = "labShowfAccount";
            this.labShowfAccount.Size = new System.Drawing.Size(178, 25);
            this.labShowfAccount.TabIndex = 0;
            this.labShowfAccount.Text = "labShowfAccount";
            // 
            // labBasicInfo
            // 
            this.labBasicInfo.AutoSize = true;
            this.labBasicInfo.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labBasicInfo.Location = new System.Drawing.Point(3, 25);
            this.labBasicInfo.Name = "labBasicInfo";
            this.labBasicInfo.Size = new System.Drawing.Size(92, 25);
            this.labBasicInfo.TabIndex = 3;
            this.labBasicInfo.Text = "基本資料";
            // 
            // labShowBasicInfo
            // 
            this.labShowBasicInfo.AutoSize = true;
            this.labShowBasicInfo.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowBasicInfo.Location = new System.Drawing.Point(3, 50);
            this.labShowBasicInfo.Name = "labShowBasicInfo";
            this.labShowBasicInfo.Size = new System.Drawing.Size(178, 25);
            this.labShowBasicInfo.TabIndex = 1;
            this.labShowBasicInfo.Text = "labShowBasicInfo";
            // 
            // labLanguage
            // 
            this.labLanguage.AutoSize = true;
            this.labLanguage.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labLanguage.Location = new System.Drawing.Point(3, 0);
            this.labLanguage.Name = "labLanguage";
            this.labLanguage.Size = new System.Drawing.Size(92, 25);
            this.labLanguage.TabIndex = 4;
            this.labLanguage.Text = "語言技能";
            // 
            // labShowLanguage
            // 
            this.labShowLanguage.AutoSize = true;
            this.labShowLanguage.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowLanguage.Location = new System.Drawing.Point(3, 25);
            this.labShowLanguage.Name = "labShowLanguage";
            this.labShowLanguage.Size = new System.Drawing.Size(186, 25);
            this.labShowLanguage.TabIndex = 2;
            this.labShowLanguage.Text = "labShowLanguage";
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.AutoSize = true;
            this.flowLayoutPanel2.Controls.Add(this.labLanguage);
            this.flowLayoutPanel2.Controls.Add(this.labShowLanguage);
            this.flowLayoutPanel2.Controls.Add(this.labEducation);
            this.flowLayoutPanel2.Controls.Add(this.labShowEducation);
            this.flowLayoutPanel2.Controls.Add(this.labSkill);
            this.flowLayoutPanel2.Controls.Add(this.labShowSkill);
            this.flowLayoutPanel2.Controls.Add(this.labPorfolio);
            this.flowLayoutPanel2.Controls.Add(this.labShowPorfolio);
            this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel2.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(585, 804);
            this.flowLayoutPanel2.TabIndex = 0;
            // 
            // labWorkExp
            // 
            this.labWorkExp.AutoSize = true;
            this.labWorkExp.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labWorkExp.Location = new System.Drawing.Point(3, 75);
            this.labWorkExp.Name = "labWorkExp";
            this.labWorkExp.Size = new System.Drawing.Size(92, 25);
            this.labWorkExp.TabIndex = 5;
            this.labWorkExp.Text = "工作經驗";
            // 
            // labShowWorkExp
            // 
            this.labShowWorkExp.AutoSize = true;
            this.labShowWorkExp.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowWorkExp.Location = new System.Drawing.Point(3, 100);
            this.labShowWorkExp.Name = "labShowWorkExp";
            this.labShowWorkExp.Size = new System.Drawing.Size(178, 25);
            this.labShowWorkExp.TabIndex = 3;
            this.labShowWorkExp.Text = "labShowWorkExp";
            // 
            // labEducation
            // 
            this.labEducation.AutoSize = true;
            this.labEducation.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labEducation.Location = new System.Drawing.Point(3, 50);
            this.labEducation.Name = "labEducation";
            this.labEducation.Size = new System.Drawing.Size(92, 25);
            this.labEducation.TabIndex = 7;
            this.labEducation.Text = "教育程度";
            // 
            // labShowEducation
            // 
            this.labShowEducation.AutoSize = true;
            this.labShowEducation.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowEducation.Location = new System.Drawing.Point(3, 75);
            this.labShowEducation.Name = "labShowEducation";
            this.labShowEducation.Size = new System.Drawing.Size(187, 25);
            this.labShowEducation.TabIndex = 4;
            this.labShowEducation.Text = "labShowEducation";
            // 
            // labSkill
            // 
            this.labSkill.AutoSize = true;
            this.labSkill.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labSkill.Location = new System.Drawing.Point(3, 100);
            this.labSkill.Name = "labSkill";
            this.labSkill.Size = new System.Drawing.Size(92, 25);
            this.labSkill.TabIndex = 8;
            this.labSkill.Text = "專業技能";
            // 
            // labShowSkill
            // 
            this.labShowSkill.AutoSize = true;
            this.labShowSkill.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowSkill.Location = new System.Drawing.Point(3, 125);
            this.labShowSkill.Name = "labShowSkill";
            this.labShowSkill.Size = new System.Drawing.Size(130, 25);
            this.labShowSkill.TabIndex = 5;
            this.labShowSkill.Text = "labShowSkill";
            // 
            // labPorfolio
            // 
            this.labPorfolio.AutoSize = true;
            this.labPorfolio.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labPorfolio.Location = new System.Drawing.Point(3, 150);
            this.labPorfolio.Name = "labPorfolio";
            this.labPorfolio.Size = new System.Drawing.Size(72, 25);
            this.labPorfolio.TabIndex = 9;
            this.labPorfolio.Text = "作品集";
            // 
            // labShowPorfolio
            // 
            this.labShowPorfolio.AutoSize = true;
            this.labShowPorfolio.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labShowPorfolio.Location = new System.Drawing.Point(3, 175);
            this.labShowPorfolio.Name = "labShowPorfolio";
            this.labShowPorfolio.Size = new System.Drawing.Size(168, 25);
            this.labShowPorfolio.TabIndex = 6;
            this.labShowPorfolio.Text = "labShowPorfolio";
            // 
            // btnDecline
            // 
            this.btnDecline.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDecline.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnDecline.Location = new System.Drawing.Point(857, 863);
            this.btnDecline.Name = "btnDecline";
            this.btnDecline.Size = new System.Drawing.Size(163, 42);
            this.btnDecline.TabIndex = 53;
            this.btnDecline.Text = "婉拒面試";
            this.btnDecline.UseVisualStyleBackColor = true;
            // 
            // btnAccept
            // 
            this.btnAccept.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAccept.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnAccept.Location = new System.Drawing.Point(1026, 863);
            this.btnAccept.Name = "btnAccept";
            this.btnAccept.Size = new System.Drawing.Size(163, 42);
            this.btnAccept.TabIndex = 54;
            this.btnAccept.Text = "邀約面試";
            this.btnAccept.UseVisualStyleBackColor = true;
            this.btnAccept.Click += new System.EventHandler(this.btnAccept_Click);
            // 
            // btnDeclineWithNoMessage
            // 
            this.btnDeclineWithNoMessage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDeclineWithNoMessage.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnDeclineWithNoMessage.Location = new System.Drawing.Point(688, 863);
            this.btnDeclineWithNoMessage.Name = "btnDeclineWithNoMessage";
            this.btnDeclineWithNoMessage.Size = new System.Drawing.Size(163, 42);
            this.btnDeclineWithNoMessage.TabIndex = 55;
            this.btnDeclineWithNoMessage.Text = "不通知婉拒面試";
            this.btnDeclineWithNoMessage.UseVisualStyleBackColor = true;
            // 
            // FrmCompanyReadResume
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1201, 952);
            this.Controls.Add(this.btnDeclineWithNoMessage);
            this.Controls.Add(this.btnAccept);
            this.Controls.Add(this.btnDecline);
            this.Controls.Add(this.splitContainer1);
            this.Name = "FrmCompanyReadResume";
            this.Text = "FrmCompanyReadResume";
            this.Load += new System.EventHandler(this.FrmCompanyReadResume_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.flowLayoutPanel2.ResumeLayout(false);
            this.flowLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label labShowfAccount;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Label labShowBasicInfo;
        private System.Windows.Forms.Label labBasicInfo;
        private System.Windows.Forms.Label labLanguage;
        private System.Windows.Forms.Label labShowLanguage;
        private System.Windows.Forms.Label labWorkExp;
        private System.Windows.Forms.Label labShowWorkExp;
        private System.Windows.Forms.Label labEducation;
        private System.Windows.Forms.Label labShowEducation;
        private System.Windows.Forms.Label labSkill;
        private System.Windows.Forms.Label labShowSkill;
        private System.Windows.Forms.Label labPorfolio;
        private System.Windows.Forms.Label labShowPorfolio;
        private System.Windows.Forms.Button btnDecline;
        private System.Windows.Forms.Button btnAccept;
        private System.Windows.Forms.Button btnDeclineWithNoMessage;
    }
}