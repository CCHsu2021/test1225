﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class FrmJobInfo : Form
    {
        public FrmJobInfo()
        {
            InitializeComponent();
        }

        private void FrmJobInfo_Load(object sender, EventArgs e)
        {
            
        }

        internal void SetInfo(long PK)
        {
            dbhelloEntities1 db = new dbhelloEntities1();

            //用FrmSerchJob的PK找tJob_Vacany的Row
            var jobVacancyTB = from p in db.tJobVacancy
                               select p;
            tJobVacancy job = jobVacancyTB.FirstOrDefault(p => p.fJobID == PK);

            //用得到的Row的CompanyID去找在tCompany_Infomation的Row
            var companyInfoTB = from p in db.tCompanyBasic
                                select p;
            tCompanyBasic company = companyInfoTB.FirstOrDefault(p => p.fBAN == job.fCompanyID);

            //道理同上
            var jobClassTB = from p in db.tJobList
                             select p;
            tJobList jobClass = jobClassTB.FirstOrDefault(p => p.JobListID == job.fJoblistID);

            //道理同上
            var skillTB = from p in db.tSkill
                          where p.fJobID.Equals(job.fJobID)
                          select p;
            
            string skillName = "";
            foreach(tSkill t in skillTB)
            {
                skillName += $"{t.fSkillName} ";
            }

            labJobName.Text = job.fJobName;
            labComponyName.Text = company.fName;
            txtShowfOther.Text = job.fOther;
            labShowJobClass.Text = jobClass.fJobListName;
            labShowSalary.Text = job.fSalary.ToString();
            labShowEmployeesType.Text = job.fEmployeesType;
            labShowWorkAddress.Text = job.fWorkAddress;
            labShowWorkHour.Text = job.fWorkHours;
            labShowLeaveSystem.Text = job.fLeaveSystem;
            labShowWorkExperience.Text = job.fWorkEXP;
            labShowEducation.Text = job.fEducation;
            labShowLanguage.Text = job.fLanguage;
            labShowJobProfessionalSkill.Text = skillName;
            txtShowBenefits.Text = company.fBenefits;
            labShowContactHR.Text = company.fContactPerson;
            labShowContactPhone.Text = company.fPhone.ToString();
            labShowContactEmail.Text = company.fEmail;

            var ImageLoad = from p in db.tPhoto
                            where p.fAccount.Equals(company.fAccount)
                            select p;
            
            List<PictureBox> pictureList = new List<PictureBox>();
            pictureList.Add(pbCompanyPhoto1);
            pictureList.Add(pbCompanyPhoto2);
            pictureList.Add(pbCompanyPhoto3);
            pictureList.Add(pbCompanyPhoto4);
            pictureList.Add(pbCompanyPhoto5);
            pictureList.Add(pbCompanyPhoto6);
            pictureList.Add(pbCompanyPhoto7);
            pictureList.Add(pbCompanyPhoto8);
            
            int i = 0;
            foreach (tPhoto t in ImageLoad)
            {
                if (i < Convert.ToInt32(ImageLoad.Count()))
                {
                    pictureList[i].Image = ByteArrayToImage(t.fPhoto);
                    i++;
                }
            }
        }

        public Image ByteArrayToImage(byte[] byteArrayIn)
        {
            using (MemoryStream ms = new MemoryStream(byteArrayIn))
            {
                Image returnImage = Image.FromStream(ms);
                return returnImage;
            }
        }

        List<tJobVacancy> tJob_Vacancies = new List<tJobVacancy>();

        private void labOtherJob_Click(object sender, EventArgs e)      //之後再實作。
        {
            dbhelloEntities1 db = new dbhelloEntities1();

            var jobVacancyTB = from p in db.tJobVacancy
                               select p;

        }

        private void btnApply_Click(object sender, EventArgs e)
        {
            FrmSendResume frmSendResume = new FrmSendResume();
            frmSendResume.Show();
        }
    }
}
